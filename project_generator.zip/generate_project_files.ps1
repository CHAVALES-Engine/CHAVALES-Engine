param(
    [Parameter(Mandatory=$true)]
    [string]$ProjectName,
    [Parameter(Mandatory=$true)]
    [string]$ProjectDir
)

$ErrorActionPreference = "Stop"

function Write-File {
    param([string]$Path, [string]$Content)
    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    Set-Content -Path $Path -Encoding UTF8 -Value $Content
    Write-Host "  Generado: $Path"
}

# ======================================================
# GameConfigurator.cpp
# ======================================================
$gameConfigurator = @"
#include "GameConfigurator.h"
// ==========================================================
//  $ProjectName - Configuracion de juego
//
//  Aqui se configura el juego, desde la ruta de las escenas hasta la resolucion de la ventana.
//  Esta configuracion se puede hacer desde:
//  - Un archivo TOML (game/config.toml).
//  - Argumentos de linea de comandos
//  - Esta funcion configureGame, que se llama al cargar la DLL
//
//  Si el motor detecta que se ha configurado el juego desde un TOML o por argumentos de linea de comandos, esta funcion no hace nada.
// ==========================================================


extern "C" __declspec(dllexport)
void configureGame()
{
    core::GameConfigurator::instance()._configType = "DLL";
    // Rutas relativas a la raiz del proyecto
    // Escenas
    core::GameConfigurator::instance()._scenesRoot = "./game/scenes/";
    core::GameConfigurator::instance()._firstScene = "example_scene";
    // Assets
    core::GameConfigurator::instance()._assetsRoot = "./game/assets/";
    core::GameConfigurator::instance()._assetsList = "assetList";
    core::GameConfigurator::instance()._iconRoot = "./game/assets/icon.ico";
    core::GameConfigurator::instance()._gameDLL = "$ProjectName.dll";
    // Configuracion de la ventana
    core::GameConfigurator::instance()._windowName = "$ProjectName";
    core::GameConfigurator::instance()._windowHeight = 720;
    core::GameConfigurator::instance()._windowWidth = 1280;
    core::GameConfigurator::instance()._clearColor = core::Color(0.2, 0.5, 0.75, 1.0);
}
"@
Write-File "$ProjectDir\game\src\GameConfigurator.cpp" $gameConfigurator

# ======================================================
# main.cpp
# ======================================================
$mainCpp = @"
#include <Engine.h>
#include <iostream>

// ==========================================================
//  $ProjectName - Punto de entrada
// ==========================================================

int main(int argc, char* argv[])
{
    std::cout << "[MAIN] Inicializando ChavalesEngine" << std::endl;
    if (Engine::init()) {
        try
        {
            Engine::instance()->startLoop();
        }
        catch (const std::exception& e)
        {
            std::cerr << "Exception: " << e.what() << std::endl;
        }
        catch (...)
        {
            std::cerr << "Unknown exception" << std::endl;
        }
        Engine::release();
        return 0;
    }
    Engine::release();
    return 1;
}
"@
Write-File "$ProjectDir\game\src\main.cpp" $mainCpp

# ======================================================
# app.rc
# ======================================================
$appRc = @"
// ==========================================================
//  $ProjectName - Recursos del juego
//  Este archivo define los recursos del juego.
//  En este caso, se define un icono para el ejecutable del juego.
//  El icono se carga desde la ruta definida en GameConfigurator.cpp (./game/assets/icon.ico).
// ==========================================================

IDI_ICON1 ICON "../../game/assets/icon.ico"
"@
Write-File "$ProjectDir\game\src\app.rc" $appRc

# ======================================================
# CMakeLists.txt
# ======================================================
$cmake = @"
cmake_minimum_required(VERSION 3.13)

# Forzar x64
set(CMAKE_GENERATOR_PLATFORM "x64" CACHE STRING "" FORCE)

project($ProjectName)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Recoge todos los .cpp de game/src/
file(GLOB_RECURSE SOURCES "game/src/*.cpp")
file(GLOB_RECURSE HEADERS "game/src/*.h")

list(REMOVE_ITEM SOURCES "`${CMAKE_CURRENT_SOURCE_DIR}/game/src/main.cpp")

# --- DLL del juego ----------------------------------
# Compilar como DLL
add_library(`${PROJECT_NAME}_dll SHARED `${SOURCES} `${HEADERS})

# Directorios de includes
target_include_directories(`${PROJECT_NAME}_dll PRIVATE
    `${CMAKE_CURRENT_SOURCE_DIR}/include/header
    `${CMAKE_CURRENT_SOURCE_DIR}/include/source
    `${CMAKE_CURRENT_SOURCE_DIR}/game/src
)

# Link con ChavalesEngine (Release)
target_link_libraries(`${PROJECT_NAME}_dll PRIVATE
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Engine/Engine_r.lib>
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Defs/Core-Defs_r.lib>
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Utils/Core-Utils_r.lib>
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/ComponentsProject/ComponentsProject_r.lib>
)

# Link con ChavalesEngine (Debug)
target_link_libraries(`${PROJECT_NAME}_dll PRIVATE
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Engine/Engine_d.lib>
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Defs/Core-Defs_d.lib>
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Utils/Core-Utils_d.lib>
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/ComponentsProject/ComponentsProject_d.lib>
)

# Salida: game/$ProjectName.dll
set_target_properties(`${PROJECT_NAME}_dll PROPERTIES
    PREFIX ""
    RUNTIME_OUTPUT_DIRECTORY         "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    RUNTIME_OUTPUT_DIRECTORY_RELEASE "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    RUNTIME_OUTPUT_DIRECTORY_DEBUG   "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    LIBRARY_OUTPUT_DIRECTORY         "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    LIBRARY_OUTPUT_DIRECTORY_RELEASE "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    LIBRARY_OUTPUT_DIRECTORY_DEBUG   "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    ARCHIVE_OUTPUT_DIRECTORY         "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    ARCHIVE_OUTPUT_DIRECTORY_RELEASE "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    ARCHIVE_OUTPUT_DIRECTORY_DEBUG   "`${CMAKE_CURRENT_SOURCE_DIR}/game"
    OUTPUT_NAME         "$ProjectName"
    OUTPUT_NAME_RELEASE "$ProjectName"
    OUTPUT_NAME_DEBUG   "${ProjectName}_d"
)

# --- Ejecutable del juego ----------------------------------
# Genera $ProjectName.exe con el icono y nombre propios.
add_executable(`${PROJECT_NAME} game/src/main.cpp game/src/app.rc)

target_include_directories(`${PROJECT_NAME} PRIVATE
    `${CMAKE_CURRENT_SOURCE_DIR}/include/header
    `${CMAKE_CURRENT_SOURCE_DIR}/include/source
)

target_link_libraries(`${PROJECT_NAME} PRIVATE
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Engine/Engine_r.lib>
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Engine/Engine_d.lib>
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Defs/Core-Defs_r.lib>
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Defs/Core-Defs_d.lib>
    `$<`$<CONFIG:Release>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Utils/Core-Utils_r.lib>
    `$<`$<CONFIG:Debug>:`${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Utils/Core-Utils_d.lib>
)

# El exe se construye despues de la DLL (no linkea contra ella,
# el engine la carga en runtime por nombre)
add_dependencies(`${PROJECT_NAME} `${PROJECT_NAME}_dll)

set_target_properties(`${PROJECT_NAME} PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY         "`${CMAKE_CURRENT_SOURCE_DIR}"
    RUNTIME_OUTPUT_DIRECTORY_RELEASE "`${CMAKE_CURRENT_SOURCE_DIR}"
    RUNTIME_OUTPUT_DIRECTORY_DEBUG   "`${CMAKE_CURRENT_SOURCE_DIR}"
    OUTPUT_NAME         "$ProjectName"
    OUTPUT_NAME_RELEASE "$ProjectName"
    OUTPUT_NAME_DEBUG   "${ProjectName}_d"
)

set_property(
    DIRECTORY
    PROPERTY
    VS_STARTUP_PROJECT
    $ProjectName
)
"@
Write-File "$ProjectDir\CMakeLists.txt" $cmake

# ======================================================
# CMakeSettings.json
# ======================================================
$cmakeSettings = @"
{
  "configurations": [
    {
      "name": "Release",
      "generator": "Visual Studio 17 2022",
      "configurationType": "Release",
      "buildRoot": "`${projectDir}\\builder",
      "platform": "x64",
      "intelliSenseMode": "windows-msvc-x64"
    },
    {
      "name": "Debug",
      "generator": "Visual Studio 17 2022",
      "configurationType": "Debug",
      "buildRoot": "`${projectDir}\\builder_debug",
      "platform": "x64",
      "intelliSenseMode": "windows-msvc-x64"
    }
  ]
}
"@
Write-File "$ProjectDir\CMakeSettings.json" $cmakeSettings

# ======================================================
# launch.vs.json
# ======================================================
$launchVs = @"
{
  "version": "0.2.1",
  "defaults": {},
  "configurations": [
    {
      "type": "default",
      "name": "$ProjectName (Release)",
      "project": "CMakeLists.txt",
      "executable": "`${workspaceRoot}\\$ProjectName.exe",
      "currentDir": "`${workspaceRoot}"
    },
    {
      "type": "default",
      "name": "$ProjectName (Debug)",
      "project": "CMakeLists.txt",
      "executable": "`${workspaceRoot}\\${ProjectName}_d.exe",
      "currentDir": "`${workspaceRoot}"
    }
  ]
}
"@
Write-File "$ProjectDir\launch.vs.json" $launchVs

# ======================================================
# .gitignore
# ======================================================
$gitignore = @"
## Ignore Visual Studio temporary files, build results, and
## files generated by popular Visual Studio add-ons.

# User-specific files
*.rsuser
*.suo
*.user
*.userosscache
*.sln.docstates
*.env

# User-specific files (MonoDevelop/Xamarin Studio)
*.userprefs

# Mono auto generated files
mono_crash.*

# Build results
[Dd]ebug/
[Dd]ebugPublic/
[Rr]elease/
[Rr]eleases/
[Bb]uilder/
[Bb]uilder_debug/

[Dd]ebug/x64/
[Dd]ebugPublic/x64/
[Rr]elease/x64/
[Rr]eleases/x64/
bin/x64/
obj/x64/

[Dd]ebug/x86/
[Dd]ebugPublic/x86/
[Rr]elease/x86/
[Rr]eleases/x86/
bin/x86/
obj/x86/

[Ww][Ii][Nn]32/
[Aa][Rr][Mm]/
[Aa][Rr][Mm]64/
[Aa][Rr][Mm]64[Ee][Cc]/
bld/
[Oo]bj/
[Oo]ut/
[Ll]og/
[Ll]ogs/

# Build results on 'Bin' directories
**/[Bb]in/*

# Carpeta de includes del juego.
include/

# Carpeta libs
libs/

# Visual Studio 2015/2017 cache/options directory
.vs/
# Carpeta donde se encuentra el repositorio del motor.
.engine/

# Visual Studio 2017 auto generated files
Generated Files/

# MSTest test Results
[Tt]est[Rr]esult*/
[Bb]uild[Ll]og.*
*.trx

# NUnit
*.VisualState.xml
TestResult.xml
nunit-*.xml

*.received.*

[Dd]ebugPS/
[Rr]eleasePS/
dlldata.c

BenchmarkDotNet.Artifacts/

project.lock.json
project.fragment.lock.json
artifacts/

ScaffoldingReadMe.txt
StyleCopReport.xml

# Cosas de imgui
imgui.ini

# Files built by Visual Studio
*_i.c
*_p.c
*_h.h
*.ilk
*.meta
*.obj
*.idb
*.iobj
*.pch
*.pdb
*.ipdb
*.pgc
*.pgd
*.rsp
!Directory.Build.rsp
*.sbr
*.tlb
*.tli
*.tlh
*.tmp
*.tmp_proj
*_wpftmp.csproj
*.log
*.tlog
*.vspscc
*.vssscc
.builds
*.pidb
*.svclog
*.scc
*.exe
*.dll
*.lib
*.exp
*.pdb

_Chutzpah*

ipch/
*.aps
*.ncb
*.opendb
*.opensdf
*.sdf
*.cachefile
*.VC.db
*.VC.VC.opendb

*.psess
*.vsp
*.vspx
*.sap
*.e2e

`$tf/
*.gpState

_ReSharper*/
*.[Rr]e[Ss]harper
*.DotSettings.user

_TeamCity*
*.dotCover

.axoCover/*
!.axoCover/settings.json

coverage*.json
coverage*.xml
coverage*.info

*.coverage
*.coveragexml

_NCrunch_*
.NCrunch_*
.*crunch*.local.xml
nCrunchTemp_*

*.mm.*
AutoTest.Net/

.sass-cache/
[Ee]xpress/

DocProject/buildhelp/
DocProject/Help/*.HxT
DocProject/Help/*.HxC
DocProject/Help/*.hhc
DocProject/Help/*.hhk
DocProject/Help/*.hhp
DocProject/Help/Html2
DocProject/Help/html

publish/

*.[Pp]ublish.xml
*.azurePubxml
*.pubxml
*.publishproj
PublishScripts/

*.nupkg
*.snupkg
**/[Pp]ackages/*
!**/[Pp]ackages/build/
*.nuget.props
*.nuget.targets

csx/
*.build.csdef
ecf/
rcf/

AppPackages/
BundleArtifacts/
Package.StoreAssociation.xml
_pkginfo.txt
*.appx
*.appxbundle
*.appxupload

*.[Cc]ache
!?*.[Cc]ache/

ClientBin/
~`$*
*~
*.dbmdl
*.dbproj.schemaview
*.jfm
*.pfx
*.publishsettings
orleans.codegen.cs

#*.snk
#bower_components/

Generated_Code/

_UpgradeReport_Files/
Backup*/
UpgradeLog*.XML
UpgradeLog*.htm
ServiceFabricBackup/
*.rptproj.bak

*.mdf
*.ldf
*.ndf

*.rdl.data
*.bim.layout
*.bim_*.settings
*.rptproj.rsuser
*- [Bb]ackup.rdl
*- [Bb]ackup ([0-9]).rdl
*- [Bb]ackup ([0-9][0-9]).rdl

FakesAssemblies/
*.GhostDoc.xml

.ntvs_analysis.dat
node_modules/

*.plg
*.opt
*.vbw
*.dsw
*.dsp
*.ncb
*.aps

**/*.HTMLClient/GeneratedArtifacts
**/*.DesktopClient/GeneratedArtifacts
**/*.DesktopClient/ModelManifest.xml
**/*.Server/GeneratedArtifacts
**/*.Server/ModelManifest.xml
_Pvt_Extensions

**/.paket/paket.exe
paket-files/
**/.fake/
**/.cr/personal
**/__pycache__/
*.pyc

*.tss
*.jmconfig

*.btp.cs
*.btm.cs
*.odx.cs
*.xsd.cs

OpenCover/
ASALocalRun/

*.binlog
MSBuild_Logs/
.aws-sam
*.nvuser
**/.mfractor/
**/.localhistory/
.vshistory/
healthchecksdb
MigrationBackup/
**/.ionide/
FodyWeavers.xsd

.vscode/*
!.vscode/settings.json
!.vscode/tasks.json
!.vscode/launch.json
!.vscode/extensions.json
!.vscode/*.code-snippets

.history/
*.vsix

*.cab
*.msi
*.msix
*.msm
*.msp
"@
Write-File "$ProjectDir\.gitignore" $gitignore

Write-Host ""
Write-Host "  Todos los archivos generados correctamente."