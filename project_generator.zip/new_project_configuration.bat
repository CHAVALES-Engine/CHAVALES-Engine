@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

:: Capturar tiempo de inicio
set "STARTTIME=%time%"

:: ================================================================
:: ChavalesEngine - Generador de configuracion del proyecto
::
:: Genera los archivos de configuracion basicos de un proyecto:
::   - GameConfigurator.cpp
::   - main.cpp
::   - app.rc
::   - CMakeLists.txt
::   - CMakeSettings.json
::   - launch.vs.json
::   - .gitignore
::
:: Uso:
::   new_project_configuration.bat NombreProyecto [RutaProyecto]
::
:: Ejemplos:
::   new_project_configuration.bat MiJuego
::   new_project_configuration.bat MiJuego ./ruta/a/elegir/
::
:: Parametros:
::   NombreProyecto  Nombre del proyecto
::   RutaProyecto    Carpeta destino (por defecto ./NombreProyecto/)
:: ================================================================

:: ======================================================
:: VERIFICAR ARGUMENTOS
:: ======================================================
if "%~1"=="" goto :usage
set "PROJECT_NAME=%~1"
set "PROJECT_DIR=./%PROJECT_NAME%/"
if not "%~2"=="" set "PROJECT_DIR=%~2"
goto :start

:usage
echo(
echo  Uso: new_project_configuration.bat ^<nombre-del-proyecto^> ^<ruta-del-proyecto ^(opcional, default: ./NombreProyecto/^)^>
echo(
echo  Crea la configuracion de proyecto por defecto, con:
echo  - un GameConfigurator.cpp de ejemplo.
echo  - un main.cpp que arranca el engine.
echo  - un app.rc con un icono de ejemplo.
echo  - CMakeLists.txt, CMakeSettings.json, launch.vs.json
echo  - .gitignore
echo(
echo  Ejemplo:
echo  new_project_configuration.bat MiJuego
echo  new_project_configuration.bat MiJuego ./ruta/personalizada/
echo(
exit /b 1

:start

:: ======================================================
:: VERIFICAR QUE LA CARPETA DE DESTINO EXISTE
:: ======================================================
if not exist "%PROJECT_DIR%" (
  echo(
  echo  [ERROR] No existe la carpeta '%PROJECT_DIR%'.
  echo  Crea el proyecto primero con new_project.bat
  echo(
  exit /b 1
)

echo(
echo  ==========================================
echo  ChavalesEngine -- Nueva Configuracion
echo  Proyecto : %PROJECT_NAME%
echo  Carpeta  : %PROJECT_DIR%
echo  ==========================================
echo(

:: ======================================================
:: DELEGAR GENERACION DE ARCHIVOS AL PS1
:: ======================================================
echo  Generando archivos de configuracion...
echo(

:: El ps1 esta al lado de este bat
set "PS1_PATH=%~dp0generate_project_files.ps1"

if not exist "%PS1_PATH%" (
  echo  [ERROR] No se encuentra generate_project_files.ps1 junto a este bat.
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1_PATH%" -ProjectName "%PROJECT_NAME%" -ProjectDir "%PROJECT_DIR%"

if errorlevel 1 (
  echo(
  echo  [ERROR] Fallo la generacion de archivos.
  exit /b 1
)

:: ======================================================
:: RESUMEN
:: ======================================================
echo(
echo  ==========================================
echo  OK  Configuracion creada en '%PROJECT_DIR%'
echo  ==========================================
echo(
echo  Pasos siguientes:
echo    1. Actualiza el motor:
echo       ^> update_engine.bat %PROJECT_DIR%
echo    2. Compila el proyecto:
echo       ^> build_game.bat %PROJECT_DIR%
echo    3. O abre la carpeta en Visual Studio y compila normalmente.
echo(

:: ======================================================
:: TIEMPO
:: ======================================================
set "ENDTIME=%time%"

for /f "tokens=1-4 delims=:,." %%a in ("!STARTTIME!") do (
  set /a "start_res=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)
for /f "tokens=1-4 delims=:,." %%a in ("!ENDTIME!") do (
  set /a "end_res=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)

set /a "diff=%end_res%-%start_res%"
set /a "ms=%diff% %% 100"
set /a "diff=%diff% / 100"
set /a "ss=%diff% %% 60"
set /a "diff=%diff% / 60"
set /a "mm=%diff% %% 60"
set /a "hh=%diff% / 60"

echo(
echo ==========================================
echo  Tiempo total: %hh%h %mm%m %ss%.%ms%s
echo ==========================================

endlocal