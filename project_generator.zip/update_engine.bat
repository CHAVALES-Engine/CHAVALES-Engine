@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

:: Capturar tiempo de inicio
set "STARTTIME=%time%"

:: =======================================================
:: ChavalesEngine - Actualizador e Instalador del Motor
::
:: Uso recomendado tras clonar un proyecto:
::
::     update_engine.bat <Proyecto>
::
:: Este script:
::   - Descarga o actualiza el motor
::   - Inicializa los submódulos necesarios
::   - Compila dependencias y motor
::   - Actualiza librerias, headers y DLLs
::
:: Despues de ejecutarlo, compila el juego con:
::
::     cd <directorio del juego>
::
::     build_game.bat 
::
:: Para ver las opciones disponibles:
::
::     update_engine.bat -h
::     update_engine.bat --help
::
:: =======================================================

:: --- COMPROBACION DE AYUDA ---
if "%~1"=="/?" goto :MOSTRAR_AYUDA
if "%~1"=="--help" goto :MOSTRAR_AYUDA
if "%~1"=="-h" goto :MOSTRAR_AYUDA
:: ------------------------------------

:: ======================================================
:: VERIFICAR ARGUMENTOS
:: ======================================================
if "%~1"=="" goto :usage
set "PROJECT_DIR=%~1"
set "BRANCH=main"
set "COMPILE_DEPS=false"
set "COMPILE_Engine=true"
if not "%~2"=="" set "BRANCH=%~2"
if not "%~3"=="" set "COMPILE_DEPS=%~3"
if not "%~4"=="" set "COMPILE_Engine=%~4"
goto :start

:usage
echo.
echo Falta indicar el proyecto.
echo.
echo Usa:
echo   update_engine.bat --help
echo.
exit /b 1

:start

:: ======================================================
:: VERIFICAR QUE EL PROYECTO EXISTE
:: ======================================================
if not exist "%PROJECT_DIR%" (
  echo(
  echo  [ERROR] No existe un proyecto en %PROJECT_DIR%.
  echo(
  exit /b 1
)

if not exist "%PROJECT_DIR%\CMakeLists.txt" (
  echo(
  echo  [ERROR] '%PROJECT_DIR%' no parece un proyecto de ChavalesEngine ^(no hay CMakeLists.txt^).
  echo(
  exit /b 1
)

echo(
echo  ==========================================
echo  ChavalesEngine -- Actualizar Motor
echo  Proyecto : %PROJECT_DIR%
echo  Rama     : %BRANCH%
echo  Compilar dependencias: %COMPILE_DEPS%
echo  Compilar engine: %COMPILE_Engine%
echo  ==========================================
echo(

:: ======================================================
:: VERIFICAR QUE EL SUBMODULO EXISTE
:: ======================================================
if not exist "%PROJECT_DIR%\.engine\" (
  echo Carpeta .engine no encontrada. Creando submodulo...
  pushd "%PROJECT_DIR%"
  git submodule add --force https://github.com/Proyecto3-FDI-UCM/2526-Grupo03-ChavalesEngine.git ".engine"
  if errorlevel 1 (
    echo  [ERROR] Fallo al añadir el submodulo .engine.
    exit /b 1
  )
  git submodule update --init --recursive
  if errorlevel 1 (
    echo  [ERROR] Fallo al inicializar el submodulo .engine.
    exit /b 1
  )
  popd
)
if not exist "%PROJECT_DIR%\.engine\.git" (
  echo Submodulo .engine no inicializado. Inicializando...
  pushd "%PROJECT_DIR%"
  git submodule update --init --recursive
  popd
)

:: ======================================================
:: [1/4] CLONAR ENGINE
:: ======================================================
set "HASH_BEFORE="
pushd "%PROJECT_DIR%\.engine"
:: Guardar hash antes de actualizar
for /f %%i in ('git rev-parse HEAD 2^>nul') do set "HASH_BEFORE=%%i"
popd

echo  [1/4] Pulleando cambios del motor..

:: Entrar en el motor, traer cambios del servidor y saltar a dev
pushd "%PROJECT_DIR%\.engine"
git merge --abort >nul 2>&1
git fetch origin %BRANCH%
git checkout %BRANCH%
git reset --hard origin/%BRANCH%
git clean -fd
git pull origin %BRANCH%
popd

if errorlevel 1 (
  echo  [ERROR] Fallo al actualizar el repositorio.
  exit /b 1
)
:: Hash después
set "HASH_AFTER="
pushd "%PROJECT_DIR%\.engine"
for /f %%i in ('git rev-parse HEAD 2^>nul') do set "HASH_AFTER=%%i"
popd

:: ======================================================
:: [2/4] COMPILAR
:: ======================================================
if "%COMPILE_DEPS%"=="false" (
  echo  Omitiendo compilacion de dependencias...
  goto :skip_deps
)


:build_deps
echo  [2/4] Compilando dependencias...
echo( | call "%PROJECT_DIR%\.engine\dependencies\dependencies_build.bat"
if errorlevel 1 (
  echo  [ERROR] Fallo al compilar dependencias.
  exit /b 1
)

:skip_deps

:: Comprobar si el engine se actualizo
if "%HASH_BEFORE%"=="%HASH_AFTER%" (
  echo Sin cambios en el engine
  if "%COMPILE_Engine%"=="false" (
    echo  Omitiendo compilacion del engine.
    goto :skip_build
  )
  echo  Compilacion de engine forzada por argumento.
)

echo  Compilando motor...
echo( | call "%PROJECT_DIR%\.engine\ChavalesEngine_build.bat"
if errorlevel 1 (
  echo  [ERROR] Fallo la compilacion del motor.
  exit /b 1
)
:: ======================================================
:: [3/4] REEMPLAZAR LIBS, HEADERS Y DLLs
:: ======================================================
echo  [3/4] Actualizando libs...
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\Engine\Engine_d.lib"                       "%PROJECT_DIR%\libs\Engine\"
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\Core-Defs\Core-Defs_d.lib"                 "%PROJECT_DIR%\libs\Core-Defs\"
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\Core-Utils\Core-Utils_d.lib"                "%PROJECT_DIR%\libs\Core-Utils\"
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\ComponentsProject\ComponentsProject_d.lib"  "%PROJECT_DIR%\libs\ComponentsProject\"

xcopy /Y /I "%PROJECT_DIR%\.engine\libs\Engine\Engine_r.lib"                       "%PROJECT_DIR%\libs\Engine\"
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\Core-Defs\Core-Defs_r.lib"                 "%PROJECT_DIR%\libs\Core-Defs\"
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\Core-Utils\Core-Utils_r.lib"                "%PROJECT_DIR%\libs\Core-Utils\"
xcopy /Y /I "%PROJECT_DIR%\.engine\libs\ComponentsProject\ComponentsProject_r.lib"  "%PROJECT_DIR%\libs\ComponentsProject\"

echo  Actualizando headers...
rd /S /Q "%PROJECT_DIR%\include\header" 2>nul
if exist "%PROJECT_DIR%\include\header" (
  echo [ERROR] No se pudo limpiar la carpeta de headers. Tienes archivos abiertos?
  exit /b 1
)
mkdir "%PROJECT_DIR%\include\header"
rd /S /Q "%PROJECT_DIR%\include\source" 2>nul
if exist "%PROJECT_DIR%\include\source" (
  echo [ERROR] No se pudo limpiar la carpeta de source. Tienes archivos abiertos?
  exit /b 1
)
mkdir "%PROJECT_DIR%\include\source"

xcopy /S /Y "%PROJECT_DIR%\.engine\src\Engine\*.h"               "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Engine\*.hpp"              "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Core-Defs\*.h"            "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Core-Defs\*.hpp"           "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Core-Utils\*.h"           "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Core-Utils\*.hpp"          "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\ComponentsProject\*.h"    "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\ComponentsProject\*.hpp"   "%PROJECT_DIR%\include\header\"

xcopy /S /Y "%PROJECT_DIR%\.engine\src\Engine\*.cpp"              "%PROJECT_DIR%\include\source\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Core-Defs\*.cpp"           "%PROJECT_DIR%\include\source\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\Core-Utils\*.cpp"          "%PROJECT_DIR%\include\source\"
xcopy /S /Y "%PROJECT_DIR%\.engine\src\ComponentsProject\*.cpp"   "%PROJECT_DIR%\include\source\"

echo  Actualizando DLLs...
:: Copia bin completo a un temporal
xcopy /Y "%PROJECT_DIR%\.engine\bin\ChavalesEditor_r.exe" "%PROJECT_DIR%\"
xcopy /Y "%PROJECT_DIR%\.engine\bin\ChavalesEditor_d.exe" "%PROJECT_DIR%\"
xcopy /Y "%PROJECT_DIR%\.engine\bin\*.dll"                "%PROJECT_DIR%\"


:: ======================================================
:: [4/4] LIMPIAR
:: ======================================================

:: Invalidar builder para forzar recompilacion con las nuevas libs
if exist "%PROJECT_DIR%\builder" (
  echo  Borrando cache de CMake para forzar recompilacion RELEASE...
  rd /S /Q "%PROJECT_DIR%\builder"
)
if exist "%PROJECT_DIR%\builder_debug" (
  echo  Borrando cache de CMake para forzar recompilacion DEBUG...
  rd /S /Q "%PROJECT_DIR%\builder_debug"
)

:skip_build

:: ======================================================
:: RESUMEN
:: ======================================================
echo(
echo  ==========================================
echo  OK  Motor actualizado en '%PROJECT_DIR%'
echo  ==========================================
echo(
echo  Recuerda recompilar el proyecto:
echo    ^> cd %PROJECT_DIR%
echo    ^>build_game.bat
echo(
echo  O desde Visual Studio, abrir la carpeta del proyecto
echo  y compilar normalmente.
echo(

:: ======================================================
:: TIEMPO
:: ======================================================
set "ENDTIME=%time%"

for /f "tokens=1-4 delims=:,." %%a in ("!STARTTIME!") do (
  set /a "start_res=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)
for /f "tokens=1-4 delims=:,." %%a in ("!ENDTIME!") do (
  set /a "end_res=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)

set /a "diff=%end_res%-%start_res%"
set /a "ms=%diff% %% 100"
set /a "diff=%diff% / 100"
set /a "ss=%diff% %% 60"
set /a "diff=%diff% / 60"
set /a "mm=%diff% %% 60"
set /a "hh=%diff% / 60"

echo(
echo ==========================================
echo  Tiempo total: %hh%h %mm%m %ss%.%ms%s
echo ==========================================

endlocal
exit /b 0

:: --- SECCION DE AYUDA EN PANTALLA ---
:MOSTRAR_AYUDA
echo ==============================================================================
echo  ChavalesEngine - Actualizar e instalar el motor
echo(                                                                            
echo  USO
echo(
echo    update_engine.bat ^<Proyecto^> [Rama] [CompilarDeps] [CompilarEngine]
echo(
echo  PARAMETROS
echo(
echo    Proyecto        Nombre del proyecto 
echo    Rama            main (por defecto), dev, etc.
echo    CompilarDeps    true o false (por defecto: false)
echo    CompilarEngine  true o false (por defecto: true)
echo(
echo  EJEMPLOS
echo(
echo    update_engine.bat PACMAN
echo    update_engine.bat PACMAN dev true true
echo(       
echo  Despues de ejecutarlo, compila el juego con:
echo(
echo    cd ^<directorio del juego^>
echo(
echo    build_game.bat 
echo ==============================================================================
echo(
pause
endlocal
exit /b 0