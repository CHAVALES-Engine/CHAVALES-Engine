@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

set NAME=Component
set OUTPUT_DIR= src

:: Permitir pasar el nombre del componente como argumento: new_component.bat MyComponent
if not "%~1"=="" set NAME=%~1
:: Permitir pasar la ruta de salida como argumento: new_component.bat MyComponent src\components
if not "%~2"=="" set OUTPUT_DIR=%~2

echo  Creando nuevo componente: %NAME% en %OUTPUT_DIR%

:: Verificar que existe OUTPUT_DIR
if not exist "%OUTPUT_DIR%" (
    echo  Creando ruta de salida: %OUTPUT_DIR%
    mkdir "%OUTPUT_DIR%"
    if errorlevel 1 (
        echo(
        echo  [ERROR] No se pudo crear la ruta de salida: %OUTPUT_DIR%
    )
    echo(
)

:: Creamos el header y el cpp del componente con un boilerplate basicos
(
    echo #include ^<Component.h^>
    echo(
    echo // ==========================================================
    echo //  %NAME% -- Component Definition
    echo //
    echo //  Los componentes se autoregistran en ChavalesEngine usando
    echo //  la macro REGISTER_COMPONENT^ %NAME% en el cpp, que se encarga
    echo //  de llenar el registro de componentes local.
    echo // ==========================================================
    echo // Incluye aqui tus cabeceras de componentes
    echo(
    echo class %NAME% : public core::Component {
    echo public:
    echo     // Constructor por defecto.
    echo     %NAME%^(^) = default;
    echo     // Destructor, no olvidar borrar memoria.
    echo     ~%NAME%^(^);
    echo(
    echo     // Consigue las propiedades del componente desde Lua.
    echo     //     - no garantiza la inicializacion de todos los componentes de la escena.
    echo     bool init^(const Properties^& p^) override;
    echo(
    echo     // Llamado una vez al entrar en la escena.
    echo     void ready^(^) override;
    echo(
    echo     // Llamado cada frame, con el deltaTime desde el ultimo frame.
    echo     void update^(uint64_t deltaTime^) override;
    echo(
    echo private:
    echo     //  Variables miembro del componente 
    echo };
) > "%OUTPUT_DIR%\%NAME%.h"

(
    echo #include ^<%NAME%.h^>
    echo #include ^<Engine.h^>
    echo #include ^<PluginSDK.h^>
    echo(
    echo // ==========================================================
    echo //  %NAME% -- Component Implementation
    echo // Implementa tus componentes aqui. Recuerda usar la macro REGISTER_COMPONENT
    echo // para que el motor los reconozca.
    echo // ==========================================================
    echo // Incluye aqui tus cabeceras de componentes 
    echo(
    echo    REGISTER_COMPONENT^(%NAME%^);
    echo(
    echo %NAME%::~%NAME%^(^) {
    echo     // Destructor, no olvidar borrar memoria.
    echo }
    echo(
    echo bool %NAME%::init^(const Properties^& p^) {
    echo     // Lee las propiedades del componente desde Lua.
    echo     //     - no garantiza la inicializacion de todos los componentes de la escena.
    echo     return true;
    echo }
    echo(
    echo void %NAME%::ready^(^) {
    echo     // Llamado una vez al entrar en la escena.
    echo     //     - garantiza la inicializacion de todos los componentes de la escena.
    echo }
    echo(
    echo void %NAME%::update^(uint64_t deltaTime^) {
    echo     // Llamado cada frame, con el deltaTime desde el ultimo frame.
    echo }
) > "%OUTPUT_DIR%\%NAME%.cpp"