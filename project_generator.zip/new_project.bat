@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

:: Capturar tiempo de inicio
set "STARTTIME=%time%"

:: ================================================================
:: |  ChavalesEngine - Generador de Proyectos  |
:: |  Windows  |
::
:: Crea la estructura inicial de un proyecto para ChavalesEngine
::
:: El proyecto generado se compila como una DLL que sera
:: cargada por el motor en tiempo de ejecucion
::
:: Uso:
::   new_project.bat NombreProyecto [RamaMotor]
::
:: Ejemplos:
::   new_project.bat MiJuego
::   new_project.bat MiJuego dev
::
:: Parametros:
::   NombreProyecto  Nombre de la carpeta/proyecto a crear
::   RamaMotor       Rama del motor a utilizar (por defecto main)
:: ===============================================================

set ENGINE_LIB=ChavalesEngine.dll
set ENGINE_BRANCH=main
:: Verificar argumento
if "%~1"=="" (
  echo(
  echo  Uso: new_project.bat ^<nombre-del-proyecto^>
  echo(
  echo  Crea un nuevo proyecto de juego para ChavalesEngine.
  echo  El proyecto se compila como DLL y el motor la carga en runtime.
  echo(
  echo  Ejemplo:
  echo  new_project.bat MiJuego
  echo(
  exit /b 1
)

if not "%~2"=="" set ENGINE_BRANCH=%~2

set PROJECT_NAME=%~1
set PROJECT_DIR=%PROJECT_NAME%

:: Verificar que no existe ya
if exist "%PROJECT_DIR%" (
  echo(
  echo  [ERROR] Ya existe un proyecto llamado '%PROJECT_NAME%' en este directorio.
  echo(
  exit /b 1
)

echo(
echo  ==========================================
echo  ChavalesEngine -- Nuevo Proyecto
echo  Creando: %PROJECT_NAME%
echo  ==========================================
echo(

:: ======================================================
::  ESTRUCTURA DE CARPETAS
:: ======================================================
echo  [1/5] Creando estructura de carpetas...

mkdir "%PROJECT_DIR%\game\scenes"
mkdir "%PROJECT_DIR%\game\assets"
mkdir "%PROJECT_DIR%\game\assets\images"
mkdir "%PROJECT_DIR%\game\assets\audio"
mkdir "%PROJECT_DIR%\game\assets\mesh"
mkdir "%PROJECT_DIR%\game\assets\fonts"
mkdir "%PROJECT_DIR%\game\assets\texture"
mkdir "%PROJECT_DIR%\game\src"
mkdir "%PROJECT_DIR%\include\header"
mkdir "%PROJECT_DIR%\include\source"
mkdir "%PROJECT_DIR%\libs\Engine"
mkdir "%PROJECT_DIR%\libs\Core-Defs"
mkdir "%PROJECT_DIR%\libs\Core-Utils"
mkdir "%PROJECT_DIR%\libs\ComponentsProject"
mkdir "%PROJECT_DIR%\bin"

:: ======================================================
:: ENGINE COMO SUBMODULO
:: ======================================================
echo  [2/5] Consiguiendo el engine...
git clone --branch %ENGINE_BRANCH% https://github.com/Proyecto3-FDI-UCM/2526-Grupo03-ChavalesEngine.git "%PROJECT_DIR%\temp_engine"
:: Ejecutar compilación de dependencias y del motor
echo  Compilando dependencias...
echo( | call "%PROJECT_DIR%\temp_engine\dependencies\dependencies_build.bat"

echo  Compilando motor...
:: Compilamos el engine para obtener las libs necesarias para el proyecto.
echo( | call "%PROJECT_DIR%\temp_engine\ChavalesEngine_build.bat"
if errorlevel 1 (
  echo  [ERROR] Fallo la compilacion del motor.
  exit /b 1
)
echo  Extrayendo librerias y headers...
:: Copia de las libs del engine al proyecto
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\Engine\Engine_d.lib"                       "%PROJECT_DIR%\libs\Engine\"
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\Core-Defs\Core-Defs_d.lib"                 "%PROJECT_DIR%\libs\Core-Defs\"
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\Core-Utils\Core-Utils_d.lib"                "%PROJECT_DIR%\libs\Core-Utils\"
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\ComponentsProject\ComponentsProject_d.lib"  "%PROJECT_DIR%\libs\ComponentsProject\"

xcopy /Y "%PROJECT_DIR%\temp_engine\libs\Engine\Engine_r.lib"                       "%PROJECT_DIR%\libs\Engine\"
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\Core-Defs\Core-Defs_r.lib"                 "%PROJECT_DIR%\libs\Core-Defs\"
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\Core-Utils\Core-Utils_r.lib"                "%PROJECT_DIR%\libs\Core-Utils\"
xcopy /Y "%PROJECT_DIR%\temp_engine\libs\ComponentsProject\ComponentsProject_r.lib"  "%PROJECT_DIR%\libs\ComponentsProject\"

:: Copia de los headers del engine al proyecto
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Engine\*.h"            "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Engine\*.hpp"            "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Core-Defs\*.h"         "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Core-Defs\*.hpp"         "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Core-Utils\*.h"        "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Core-Utils\*.hpp"        "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\ComponentsProject\*.h" "%PROJECT_DIR%\include\header\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\ComponentsProject\*.hpp" "%PROJECT_DIR%\include\header\"

:: Copia de los sources del engine al proyecto
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Engine\*.cpp"            "%PROJECT_DIR%\include\source\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Core-Defs\*.cpp"         "%PROJECT_DIR%\include\source\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\Core-Utils\*.cpp"        "%PROJECT_DIR%\include\source\"
xcopy /S /Y "%PROJECT_DIR%\temp_engine\src\ComponentsProject\*.cpp" "%PROJECT_DIR%\include\source\"
:: Copia de las DLLs y ejecutable del engine a bin\
xcopy /Y "%PROJECT_DIR%\temp_engine\bin\*.*" "%PROJECT_DIR%\bin\"
:: sacamos de bin lo necesario para el proyecto y lo movemos a su sitio
move /Y "%PROJECT_DIR%\bin\ChavalesEditor_r.exe" "%PROJECT_DIR%\"
move "%PROJECT_DIR%\bin\*.dll" "%PROJECT_DIR%\"
:: limpiamos bin, no lo necesitamos
rd /S /Q "%PROJECT_DIR%\bin"

:: Copiar assets base del engine
xcopy /S /Y "%PROJECT_DIR%\temp_engine\bin\game\assets\" "%PROJECT_DIR%\game\assets\"

echo  Eliminando codigo fuente del motor...
rd /S /Q "%PROJECT_DIR%\temp_engine"

:: ======================================================
:: PLANTILLAS
:: ======================================================
echo  [3/5] Generando escenas Lua...
call "./new_scene.bat" "example_scene" "%PROJECT_DIR%\game\scenes"
xcopy /Y "new_scene.bat" "%PROJECT_DIR%\"

echo  [4/5] Generando boilerplate C++...
call "./new_component.bat" "ExampleComponent" "%PROJECT_DIR%\game\src"
xcopy /Y "new_component.bat" "%PROJECT_DIR%\"

echo  [5/5] Generando configuracion de proyecto...
call "./new_project_configuration.bat" "%PROJECT_NAME%" "%PROJECT_DIR%"

:: ======================================================
:: build_game.bat
:: ======================================================
echo  [5/5] Compilado de proyecto [build_game.bat]...

(
echo @echo off
echo setlocal enabledelayedexpansion
echo(
echo :: =========================================================
echo :: ^|  ChavalesEngine - Compilar %PROJECT_NAME%  ^|
echo :: =========================================================
echo(
echo set BUILD_DIR=builder
echo set CONFIG=Release
echo(
echo if not "%%~1"=="" set CONFIG=%%~1
echo if not "%%~2"=="" set BUILD_DIR=%%~2
echo(
echo echo(
echo echo  ==========================================
echo echo  Compilando %PROJECT_NAME% -- %%CONFIG%%
echo echo  ==========================================
echo echo(
echo(
echo if not exist "CMakeLists.txt" ^(
echo  echo  [ERROR] No se encuentra CMakeLists.txt
echo  echo  Ejecuta este bat desde la carpeta %PROJECT_DIR%.
echo  exit /b 1
echo ^)
echo(
echo rd /S /Q "%%BUILD_DIR%%"
echo(
echo if not exist "%%BUILD_DIR%%" ^(
echo  echo  Configurando CMake...
echo  mkdir "%%BUILD_DIR%%"
echo  cmake -S . -B "%%BUILD_DIR%%"
echo  if errorlevel 1 ^(
echo  echo  [ERROR] CMake fallo al configurar el proyecto.
echo  exit /b 1
echo  ^)
echo ^) else ^(
echo  echo  Carpeta %%BUILD_DIR%% ya existe, omitiendo configuracion.
echo ^)
echo(
echo echo  Compilando...
echo cmake --build "%%BUILD_DIR%%" --config %%CONFIG%%
echo(
echo if errorlevel 1 ^(
echo  echo  [ERROR] La compilacion fallo.
echo  exit /b 1
echo ^)
echo(
echo echo  ==========================================
echo echo  OK  DLL compilada en game\
echo echo  ==========================================
echo echo(
echo endlocal
) > "%PROJECT_DIR%\build_game.bat"

:: Placeholder para libs/
type nul > "%PROJECT_DIR%\libs\.gitkeep"

:: ======================================================
::  RESUMEN
:: ======================================================
echo(
echo  ==========================================
echo  OK  Proyecto '%PROJECT_NAME%' creado.
echo  ==========================================
echo(
echo  %PROJECT_DIR%\
echo  ^|-- game\
echo  ^|  ^|-- scenes\
echo  ^|  ^|  ^`-- example_scene.lua
echo  ^|  ^|-- assets\
echo  ^|  ^|  ^|-- images\
echo  ^|  ^|  ^|-- mesh\
echo  ^|  ^|  ^|-- fonts\
echo  ^|  ^|  ^|-- texture\
echo  ^|  ^|  ^`-- audio\
echo  ^|  ^`-- src\
echo  ^|  ^|-- ExampleComponent.h
echo  ^|  ^|-- ExampleComponent.cpp
echo  ^|  ^|-- GameConfigurator.cpp
echo  ^|  ^|-- main.cpp
echo  ^|  ^`-- app.rc
echo  ^|-- include\
echo  ^|  ^|-- header\  ^<-- headers del engine
echo  ^|  ^`-- source\  ^<-- sources del engine
echo  ^|-- libs\
echo  ^|  ^|-- Engine\
echo  ^|  ^|-- Core-Defs\
echo  ^|  ^|-- Core-Utils\
echo  ^|  ^`-- ComponentsProject\
echo  ^|-- bin\  ^<-- DLLs y ejecutable del engine
echo  ^|-- builder\  ^<-- cache de CMake
echo  ^|-- new_scene.bat
echo  ^|-- new_component.bat
echo  ^|-- build_game.bat  ^<-- compila la DLL
echo  ^`-- CMakeLists.txt
echo(
echo  Para compilar:
echo  cd %PROJECT_DIR%
echo  build_game.bat
echo(

:: Lógica para calcular la diferencia (formato HH:MM:SS,CC)
set "ENDTIME=%time%"
set "start=!STARTTIME:,=.!"
set "end=!ENDTIME:,=.!"

:: separa los componentes de tiempo y convierte a centisegundos
:: horas  -> %%a * 60  = horas en minutos
:: minutos  -> + 1%%b % 100  = + minutos reales
::  -> * 60  = todo en segundos
:: segundos -> + 1%%c % 100  = + segundos reales
::  -> * 100  = todo en centisegundos
:: centiseg -> + 1%%d % 100  = + centisegundos reales
for /f "tokens=1-4 delims=:,." %%a in ("!STARTTIME!") do (
  set /a "start_res=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)

for /f "tokens=1-4 delims=:,." %%a in ("!ENDTIME!") do (
  set /a "end_res=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)

set /a "diff=%end_res%-%start_res%"

:: Convertir de nuevo a formato legible
set /a "ms=%diff% %% 100"
set /a "diff=%diff% / 100"
set /a "ss=%diff% %% 60"
set /a "diff=%diff% / 60"
set /a "mm=%diff% %% 60"
set /a "hh=%diff% / 60"

echo(
echo ==========================================
echo  Tiempo total: %hh%h %mm%m %ss%.%ms%s
echo ==========================================

endlocal
