@echo off

:: ===========================================================================
:: ChavalesEngine - Generador de escenas
::
:: Crea una escena Lua base con entidades y componentes de ejemplo
::
:: Uso:
::   new_scene.bat NombreEscena [RutaSalida]
::
:: Ejemplos:
::   new_scene.bat MainMenu
::   new_scene.bat NivelUno game\scenes
::
:: Parametros:
::   NombreEscena  Nombre del archivo .lua a generar
::   RutaSalida    Carpeta donde se crea la escena (por defecto game\scenes)
:: ===========================================================================

chcp 65001 > nul
setlocal enabledelayedexpansion

set NAME=Scene
set OUTPUT_DIR=game\scenes

:: Permitir pasar el nombre de la escena como argumento: new_scene.bat MyScene
if not "%~1"=="" set NAME=%~1
:: Permitir pasar la ruta de salida como argumento: new_scene.bat MyScene src\scenes
if not "%~2"=="" set OUTPUT_DIR=%~2

echo  Creando nueva escena: %NAME% en %OUTPUT_DIR%

:: Verificar que existe OUTPUT_DIR
if not exist "%OUTPUT_DIR%" (
    echo  Creando ruta de salida: %OUTPUT_DIR%
    mkdir "%OUTPUT_DIR%"
    if errorlevel 1 (
        echo(
        echo  [ERROR] No se pudo crear la ruta de salida: %OUTPUT_DIR%
    )
    echo(
)

(
    echo -- %NAME% ejemplo
    echo scene = { -- entidades en escena
    echo    gizmos = false, -- mostrar gizmos de debug
    echo    entities = {
    echo    camera = { -- nombre de la entidad
    echo            ddol = false, -- Entidad dont destroy on load (permanece entre escenas)
    echo    		components = { -- componentes de esa entidad
    echo    			Transform = { -- componente transform
    echo    				-- posicion local
    echo    				position = Vector3.new^(200.0,200.0,200.0^),
    echo    				-- rotacion local
    echo    				rotation = Quaternion.new^(0.0,0.0,1.0,45.0^),
    echo    				-- escala local
    echo    				scale = Vector3.new^(1^)
    echo    			},
    echo 			Camera = {
    echo 				  FOVy = 1.0,
    echo 				  nearPlane = 0.1,
    echo 				  farPlane = 10000.0,
    echo 				  ["focal length"] = 60.0
    echo 				  --["background color"] = Color.new^(0.5,0.5,0.5,1^)
    echo    			},
    echo 			ComponentTest = {
    echo 				velocity = 1000
    echo 			},
    echo             AudioListener = {
    echo            }
    echo 		}
    echo    },
    echo    gizmo = {
    echo            ddol = false,
    echo            components = {
    echo                Transform = {
    echo                    position = Vector3.new^(0,0,0^),
    echo                    rotation = Quaternion.new^(^),
    echo                    scale = Vector3.new^(1.0^),
    echo                    },
    echo                ModelRenderer = {
    echo                    file = "gizmo",
    echo                    ["number of textures"] = 0
    echo                }
    echo            }
    echo    },
    echo    light = {
    echo        ddol = false,
    echo 		components = {
    echo 			Transform = {
    echo 				position = Vector3.new^(0,0,0^),
    echo 				rotation = Quaternion.new^(^),
    echo 				scale = Vector3.new^(0.5^)
    echo 				},
    echo 			Light = {
    echo 				type = 1,
    echo 				color = Color.new^(1,1,1,1^),
    echo 				intensity = 1.0, 
    echo 				inner   = 30.0,
    echo 				outer   = 60.0,
    echo 				falloff = 1.0
    echo 			}
    echo 		}
    echo    }
    echo    }
    echo }
) > "%OUTPUT_DIR%\%NAME%.lua"

if exist "%OUTPUT_DIR%\%NAME%.lua" (
    echo [OK] Escena guardada correctamente.
) else (
    echo [ERROR] No se pudo crear el archivo .lua
)