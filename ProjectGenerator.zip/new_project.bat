@echo off
setlocal enabledelayedexpansion

:: ════════════════════════════════════════════════════════
:: |       ChavalesEngine - Generador de Proyectos        |
:: |                    Windows                           |
:: ════════════════════════════════════════════════════════

:: set ENGINE_LIB=ChavalesEngine.dll
:: 
:: :: Verificar argumento
:: if "%~1"=="" (
::     echo.
::     echo  Uso: new_project.bat ^<nombre-del-proyecto^>
::     echo.
::     echo  Crea un nuevo proyecto de juego para ChavalesEngine.
::     echo  El proyecto se compila como DLL y el motor la carga en runtime.
::     echo.
::     echo  Ejemplo:
::     echo    new_project.bat MiPrimerJuego
::     echo.
::     exit /b 1
:: )
:: 
set PROJECT_NAME=%~1
set PROJECT_DIR=%PROJECT_NAME%
:: 
:: :: Verificar que no existe ya
:: if exist "%PROJECT_DIR%" (
::     echo.
::     echo  [ERROR] Ya existe un proyecto llamado '%PROJECT_NAME%' en este directorio.
::     echo.
::     exit /b 1
:: )
:: 
:: echo.
:: echo  ==========================================
:: echo   ChavalesEngine -- Nuevo Proyecto
:: echo   Creando: %PROJECT_NAME%
:: echo  ==========================================
:: echo.
:: 
:: :: ======================================================
:: ::  ESTRUCTURA DE CARPETAS
:: :: ======================================================
:: echo  [1/5] Creando estructura de carpetas...
:: 
 mkdir "%PROJECT_DIR%\game\scenes"
 mkdir "%PROJECT_DIR%\game\assets"
 mkdir "%PROJECT_DIR%\game\src"
:: mkdir "%PROJECT_DIR%\include"
:: mkdir "%PROJECT_DIR%\libs"
:: mkdir "%PROJECT_DIR%\builder"
:: 
:: :: ======================================================
:: :: ENGINE COMO SUBMODULO
:: :: ======================================================
:: echo  [2/5] Consiguiendo el engine...
:: 
:: git -C "%PROJECT_DIR%" init
:: 
:: if not exist "%PROJECT_DIR%\engine_src\.git" (
::     echo Anyadiendo submodulo...
::     git -C "%PROJECT_DIR%" submodule add https://github.com/Proyecto3-FDI-UCM/2526-Grupo03-ChavalesEngine.git engine_src
::     call "%PROJECT_DIR%\engine_src\dependencies\dependencies_build.bat"
:: ) else (
::     echo Submodulo ya existe, actualizando...
::     git -C "%PROJECT_DIR%" submodule update --init --recursive
:: )
:: 
:: :: Compilamos el engine para obtener las libs necesarias para el proyecto.
:: call "%PROJECT_DIR%\engine_src\ChavalesEngine_build.bat"
:: 
:: :: Copia de las libs del engine al proyecto
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\Engine\Engine_r.lib"                        "%PROJECT_DIR%\libs\Engine\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\Engine\Engine_d.lib"                        "%PROJECT_DIR%\libs\Engine\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\Core-Defs\Core-Defs_r.lib"                  "%PROJECT_DIR%\libs\Core-Defs\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\Core-Defs\Core-Defs_d.lib"                  "%PROJECT_DIR%\libs\Core-Defs\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\Core-Utils\Core-Utils_r.lib"                 "%PROJECT_DIR%\libs\Core-Utils\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\Core-Utils\Core-Utils_d.lib"                 "%PROJECT_DIR%\libs\Core-Utils\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\ComponentsProject\ComponentsProject_r.lib"   "%PROJECT_DIR%\libs\ComponentsProject\"
:: xcopy /Y "%PROJECT_DIR%\engine_src\libs\ComponentsProject\ComponentsProject_d.lib"   "%PROJECT_DIR%\libs\ComponentsProject\"
:: 
:: :: Copia de los headers del engine al proyecto
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\Engine\*.h"            "%PROJECT_DIR%\include\header\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\Core-Defs\*.h"         "%PROJECT_DIR%\include\header\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\Core-Utils\*.h"        "%PROJECT_DIR%\include\header\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\ComponentsProject\*.h" "%PROJECT_DIR%\include\header\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\Engine\*.cpp"            "%PROJECT_DIR%\include\source\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\Core-Defs\*.cpp"         "%PROJECT_DIR%\include\source\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\Core-Utils\*.cpp"        "%PROJECT_DIR%\include\source\"
:: xcopy /S /Y "%PROJECT_DIR%\engine_src\src\ComponentsProject\*.cpp" "%PROJECT_DIR%\include\source\"
:: 
:: :: Copia de las DLLs y ejecutable del engine a game\
:: xcopy /Y "%PROJECT_DIR%\engine_src\bin\*.*" "%PROJECT_DIR%\game\"
:: 
:: :: Renombrar el ejecutable del engine al nombre del juego
:: if exist "%PROJECT_DIR%\game\ExecutableProject_d.exe" rename "%PROJECT_DIR%\game\ExecutableProject_d.exe" "%PROJECT_NAME%_d.exe"
:: if exist "%PROJECT_DIR%\game\ExecutableProject_r.exe" rename "%PROJECT_DIR%\game\ExecutableProject_r.exe" "%PROJECT_NAME%_r.exe"
:: if exist "%PROJECT_DIR%\game\ExecutableProject_d.pdb" rename "%PROJECT_DIR%\game\ExecutableProject_d.pdb" "%PROJECT_NAME%_d.pdb"
:: if exist "%PROJECT_DIR%\game\ExecutableProject_r.pdb" rename "%PROJECT_DIR%\game\ExecutableProject_r.pdb" "%PROJECT_NAME%_r.pdb"
:: 
:: ======================================================
:: PLANTILLAS
:: ======================================================
echo  [3/5] Generando escenas Lua...
call "./new_scene.bat" "example_scene" "%PROJECT_DIR%\game\scenes"
xcopy /Y "new_scene.bat" "%PROJECT_DIR%\"

echo  [4/5] Generando boilerplate C++...
call "./new_component.bat" "ExampleComponent" "%PROJECT_DIR%\game\src"
xcopy /Y "new_component.bat" "%PROJECT_DIR%\"

:: ======================================================
:: CMakeLists.txt
:: ======================================================
echo  [5/5] Generando CMakeLists.txt...

(
    echo cmake_minimum_required^(VERSION 3.13^)
    echo project^(%PROJECT_NAME%^)
    echo set^(CMAKE_CXX_STANDARD 17^)
    echo set^(CMAKE_CXX_STANDARD_REQUIRED ON^)
    echo.
    echo # Recoge todos los .cpp de game/src/
    echo file^(GLOB_RECURSE SOURCES "game/src/*.cpp"^)
    echo.
    echo # Compilar como DLL
    echo add_library^(${PROJECT_NAME} SHARED ${SOURCES}^)
    echo.
    echo # Directorios de includes
    echo target_include_directories^(${PROJECT_NAME} PRIVATE
    echo     ${CMAKE_CURRENT_SOURCE_DIR}/include/header
    echo     ${CMAKE_CURRENT_SOURCE_DIR}/include/source
    echo     ${CMAKE_CURRENT_SOURCE_DIR}/game/src
    echo ^)
    echo.
    echo # Link con ChavalesEngine ^(Release y Debug^)
    echo target_link_libraries^(${PROJECT_NAME} PRIVATE
    echo     $^<$^<CONFIG:Release^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/Engine/Engine_r.lib^>
    echo     $^<$^<CONFIG:Release^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Defs/Core-Defs_r.lib^>
    echo     $^<$^<CONFIG:Release^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Utils/Core-Utils_r.lib^>
    echo     $^<$^<CONFIG:Release^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/ComponentsProject/ComponentsProject_r.lib^>
    echo     $^<$^<CONFIG:Debug^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/Engine/Engine_d.lib^>
    echo     $^<$^<CONFIG:Debug^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Defs/Core-Defs_d.lib^>
    echo     $^<$^<CONFIG:Debug^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/Core-Utils/Core-Utils_d.lib^>
    echo     $^<$^<CONFIG:Debug^>:${CMAKE_CURRENT_SOURCE_DIR}/libs/ComponentsProject/ComponentsProject_d.lib^>
    echo ^)
    echo.
    echo # Salida: game/%PROJECT_NAME%.dll
    echo set_target_properties^(${PROJECT_NAME} PROPERTIES
    echo     RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/game"
    echo     LIBRARY_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/game"
    echo     ARCHIVE_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/game"
    echo     OUTPUT_NAME               "%PROJECT_NAME%"
    echo ^)
) > "%PROJECT_DIR%\CMakeLists.txt"

:: ======================================================
:: build_game.bat
:: ======================================================
(
    echo @echo off
    echo setlocal enabledelayedexpansion
    echo.
    echo :: ════════════════════════════════════════════════════════
    echo :: ^|   ChavalesEngine - Compilar %PROJECT_NAME%          ^|
    echo :: ════════════════════════════════════════════════════════
    echo.
    echo set BUILD_DIR=builder
    echo set CONFIG=Release
    echo.
    echo if not "%%~1"=="" set CONFIG=%%~1
    echo if not "%%~2"=="" set BUILD_DIR=%%~2
    echo.
    echo echo.
    echo echo  ==========================================
    echo echo   Compilando %PROJECT_NAME% -- %%CONFIG%%
    echo echo  ==========================================
    echo echo.
    echo.
    echo if not exist "CMakeLists.txt" ^(
    echo     echo  [ERROR] No se encuentra CMakeLists.txt
    echo     echo  Ejecuta este bat desde la raiz del proyecto.
    echo     exit /b 1
    echo ^)
    echo.
    echo if not exist "%%BUILD_DIR%%" ^(
    echo     echo  Configurando CMake...
    echo     mkdir "%%BUILD_DIR%%"
    echo     cmake -S . -B "%%BUILD_DIR%%"
    echo     if errorlevel 1 ^(
    echo         echo  [ERROR] CMake fallo al configurar el proyecto.
    echo         exit /b 1
    echo     ^)
    echo ^) else ^(
    echo     echo  Carpeta %%BUILD_DIR%% ya existe, omitiendo configuracion.
    echo ^)
    echo.
    echo echo  Compilando...
    echo cmake --build "%%BUILD_DIR%%" --config %%CONFIG%%
    echo.
    echo if errorlevel 1 ^(
    echo     echo  [ERROR] La compilacion fallo.
    echo     exit /b 1
    echo ^)
    echo.
    echo echo  ==========================================
    echo echo   OK  DLL compilada en game\
    echo echo  ==========================================
    echo echo.
    echo endlocal
) > "%PROJECT_DIR%\build_game.bat"

:: Placeholder para libs/
type nul > "%PROJECT_DIR%\libs\.gitkeep"

:: ======================================================
::  RESUMEN
:: ======================================================
echo.
echo  ==========================================
echo   OK  Proyecto '%PROJECT_NAME%' creado.
echo  ==========================================
echo.
echo   %PROJECT_DIR%\
echo   ^|-- game\
echo   ^|   ^|-- scenes\
echo   ^|   ^|   ^`-- example_scene.lua
echo   ^|   ^`-- assets\
echo   ^|-- src\
echo   ^|   ^|-- ExampleComponent.h
echo   ^|   ^`-- ExampleComponent.cpp
echo   ^|-- include\               ^<-- headers del engine
echo   ^|-- libs\                  ^<-- libs del engine
echo   ^|-- engine_src\            ^<-- codigo fuente del engine
echo   ^|-- build_game.bat         ^<-- compila la DLL
echo   ^`-- CMakeLists.txt
echo.
echo   Para compilar:
echo     cd %PROJECT_DIR%
echo     build_game.bat            ^<-- Release
echo     build_game.bat Debug      ^<-- Debug
echo.

endlocal